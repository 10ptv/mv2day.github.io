// js/script.js

// Add your custom JavaScript code here