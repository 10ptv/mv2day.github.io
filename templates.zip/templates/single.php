<?php

get_header();
get_template_part( 'template-parts/single' );
get_footer();